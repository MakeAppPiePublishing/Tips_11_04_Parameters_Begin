// An exercise file for iOS Development Tips Weekly
// A weekly course on LinkedIn Learning for iOS developers
//  Season 11 (Q3 2020) video 04
//  by Steven Lipton (C)2020, All rights reserved
// Learn more at https://linkedin-learning.pxf.io/YxZgj
//This Week:  Look deeper into the world of function parameters
//  For more code, go to http://bit.ly/AppPieGithub

import UIKit


func volume(diameter:Double,a:Double) -> Double{
    let pi = Double.pi
    let z = diameter / 2.0
    return pi * z * z * a
}

volume(diameter:10,a:2)
